@echo off
setlocal EnableExtensions EnableDelayedExpansion

REM Windows' own tools first. A batch file is written for the commands cmd
REM comes with, and a PATH that puts something else of the same name in
REM front of them changes what this script does.
set "PATH=%SystemRoot%\System32;%PATH%"

REM %1 = absolute path to avr-g++
REM %2 = sketch path
REM %3 = build path
REM %4 = build project name
REM %5.. = flag names ("release_flags", "debug_flags", "cpp_flags")
REM
REM All of them are handled in one go: they are looked for in the same
REM preprocessed source, and preprocessing the sketch is the expensive part.

set "COMPILER=%~1"
set "SKETCH_PATH=%~2"
set "BUILD_PATH=%~3"
set "PROJECT_NAME=%~4"

if "%COMPILER%"=="" goto :usage
if "%SKETCH_PATH%"=="" goto :usage
if "%BUILD_PATH%"=="" goto :usage
if "%PROJECT_NAME%"=="" goto :usage
if "%~5"=="" goto :usage

REM Everything from the fifth argument on is a flag name.
set "FLAGS="
:collect
if "%~5"=="" goto :collected
set "FLAGS=%FLAGS% %~5"
shift /5
goto :collect
:collected

set "IN_FILE=%SKETCH_PATH%\%PROJECT_NAME%"
set "TMP_OUT=%BUILD_PATH%\pragma_preproc.tmp"
set "TMP_ERR=%BUILD_PATH%\pragma_preproc.err"
set "TMP_HITS=%BUILD_PATH%\pragma_preproc.hits"
set "OSKETCH=%BUILD_PATH%\sketch\\*.o" 
set "OSKETCH=%OSKETCH:\\=\%"
set "OCORE=%BUILD_PATH%\\core\\*.o" 
set "OCORE=%OCORE:\\=\%"
set "ACORE=%BUILD_PATH%\\core\\*.a" 
set "ACORE=%ACORE:\\=\%"
set "CACHEFOLDER=%BUILD_PATH%\\..\\.."

REM How many entries the cache folder has, counted by the shell rather than
REM by FIND. FIND is not necessarily the FIND that was meant: anyone with Git
REM for Windows on the PATH, which includes every CI runner, has a GNU find
REM ahead of it, and that one reads /C /V "" as three directories to search,
REM starts at the root of the drive and walks all of it. The build does not
REM hang then, it waits for someone to finish searching C:.
set "CNT=0"
PUSHD "%CACHEFOLDER%"
for /f "delims=" %%A in ('dir /b 2^>nul') do set /a CNT+=1
POPD

if not exist "%BUILD_PATH%" mkdir "%BUILD_PATH%" >nul 2>nul

if not exist "%IN_FILE%" (
  echo ERROR: Input file not found: "%IN_FILE%"
  exit /b 3
)

"%COMPILER%" -fpreprocessed -dD -E -x c++ "%IN_FILE%" 1>"%TMP_OUT%" 2>"%TMP_ERR%"
if %ERRORLEVEL% EQU 1 (
  REM keep quiet by default; uncomment next 2 lines for debugging
  echo ERROR: Preprocessor failed. stderr:
  type "%TMP_ERR%"
  exit /b 4
)

REM The loop in :one_flag spends two processes and two subroutine calls on
REM every line it is given, and preprocessed output has tens of thousands of
REM them. One findstr over the whole file leaves the handful that can match,
REM and every flag name is looked for in that handful.
findstr /I /C:"pragma" "%TMP_OUT%" > "%TMP_HITS%"

set "CHANGED=0"
for %%F in (%FLAGS%) do call :one_flag "%%F"

if !CHANGED! equ 1 (
   echo "Options changed: Deleting cached object files"
   del "%OSKETCH%" 2>NUL
   del "%OCORE%" 2>NUL
   del "%ACORE%" 2>NUL
   set WRONG=0
   dir /b cores 2>nul >nul
   if !ERRORLEVEL! EQU 0 (
      FOR /D %%P IN ("%CACHEFOLDER%\\CORES\\*") DO (
       	  if not exist "%%P\\core.a" set WRONG=1
       	  if not exist "%%P\\.last-used" set WRONG=1
   	  )
   )

   if exist "%CACHEFOLDER%\\sketches" (
      dir /a-d "%CACHEFOLDER%\\sketches" 2>nul >nul
      if errorlevel 1 (
      	 if exist "%CACHEFOLDER%\\cores" (
	    dir /a-d "%CACHEFOLDER%\\cores" 2>nul >nul
	    if errorlevel 1 (
               if %CNT% equ 2 (
	          if !WRONG! equ 0 (
                     echo "Delete cached cores"
                     rd /s/q "%CACHEFOLDER%\\cores"
		  )
               )
	    )
         )
      )
   ) 
)

endlocal
exit /b 0

:one_flag
set "FLAG_NAME=%~1"
set "OUT_FILE=%BUILD_PATH%\options.%FLAG_NAME%"
set "BAK_FILE=%OUT_FILE%.bak"
if not exist "%OUT_FILE%" (
   copy NUL "%BAK_FILE%" >nul
) else (
   copy/y "%OUT_FILE%" "%BAK_FILE%" >nul
)

set "OPTIONS="

for /f "usebackq delims=" %%L in ("%TMP_HITS%") do (
  set "LINE=%%L"
  set "HASH=0"
  REM 1) Convert TABs to spaces
  for /f "delims=" %%T in ("!LINE!") do set "LINE=%%T"
  REM Above looks like a no-op, but it keeps delayed expansion happy.

  REM Actual tab-to-space replacement:
  REM (batch can contain literal TAB between the quotes below)
  set "LINE=!LINE:	= !"

  REM 2) Left-trim spaces (repeat enough times)
  call :ltrim LINE

  REM 3) Drop leading '#' if present, then trim again
  if "!LINE:~0,1!"=="#" (
    set "HASH=1"
    set "LINE=!LINE:~1!"
    call :ltrim LINE
  )

  REM 4) Normalize multiple spaces down to single spaces
  call :collapse_spaces LINE

  REM Now we can match deterministically
  REM Accept both "pragma arduino debug_flags", "pragma arduino release_flags", and "pragma arduino cpp_flags"
  echo "!LINE!" | findstr /I /C:"pragma arduino %FLAG_NAME% " >nul
  if not errorlevel 1 (
    if !HASH! EQU 1 (
      REM Strip prefix
      set "LINE=!LINE:pragma arduino %FLAG_NAME% =!"

      REM Trim again, collapse again (in case there were extra spaces)
      call :ltrim LINE
      call :collapse_spaces LINE

      if defined LINE (
        if defined OPTIONS (
          set "OPTIONS=!OPTIONS! !LINE!"
        ) else (
          set "OPTIONS=!LINE!"
        )
      )
    )
  )
)

> "%OUT_FILE%" (<nul set /p ="%OPTIONS% ")

FC "%OUT_FILE%" "%BAK_FILE%" > NUL
if errorlevel 1 set "CHANGED=1"
del "%BAK_FILE%" >nul 2>nul
exit /b

:ltrim
setlocal EnableDelayedExpansion
set "s=!%~1!"
:lt_loop
if defined s if "!s:~0,1!"==" " (
  set "s=!s:~1!"
  goto :lt_loop
)
endlocal & set "%~1=%s%"
exit /b

:collapse_spaces
setlocal EnableDelayedExpansion
set "s=!%~1!"
:cs_loop
set "t=!s:  = !"
if not "!t!"=="!s!" (
  set "s=!t!"
  goto :cs_loop
)
endlocal & set "%~1=%s%"
exit /b

:usage
echo Usage: %~nx0 ^<path-to-avr-g++^> ^<sketch_path^> ^<build_path^> ^<project_name^> ^<flag_name^> ...
exit /b 2
